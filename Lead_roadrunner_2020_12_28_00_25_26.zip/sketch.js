var backgroundImage,myBackground,monkey,monkeyAnimation;

function preload() {
  backgroundImage = loadImage("jungle.jpg");
  //monkeyAnimation = loadAnimation("Monkey_01.png","Monkey_02.png");
  monkeyAnimation = loadImage("Monkey_02.png")
}
function setup() {
  createCanvas(600, 600);
  myBackground = createSprite(0,0,600,600);
  myBackground.addImage(backgroundImage);
  myBackground.scale = 1.5;
  
  monkey = createSprite(100,350,10,10);
  monkey.addImage(monkeyAnimation);
  monkey.scale = 0.18;
}

function draw() {
  background(220);
  
  drawSprites();
}